<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title> Contact Us - CodeRepublics </title>
        <link rel="icon" type="image/ico" href="../CodeRepublics-logo.png">
    <meta name="Description" content="Your feedback is really important to us, so please feel free to drop us a line. If you are expecting a response, you will need to provide us your email* address, of course.">
    <meta name="msvalidate.01" content="7F40FABF96B8D4DC58E056193624458E" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Keywords" content="html intro,html basic,seo,digital marketing,CSS,JavaScript,beginners,professionals,introduction,example,SQL,PHP,jQuery,XML,DOM,Bootstrap,Python,Web development,tutorials,programming,training,learning,examples,source code.">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta property="og:url"                content="https://www.coderepublics.com/contact-us/contact-view.php" />
    <meta property="og:type"               content="article" />
    <meta property="og:title"              content="Contact Us - CodeRepublics " />
    <meta property="og:description"        content="Your feedback is really important to us, so please feel free to drop us a line. If you are expecting a response, you will need to provide us your email* address, of course." />
    <meta property="og:image"              content="../assets/img/CodeRepublics.jpg" />
    <meta property="og:locale" 			   content="en_US" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="canonical" href="https://www.coderepublics.com/contact-us/contact-view.php" />
    <meta name="twitter:title" property="og:title" content="Contact Us - CodereRublics" />
    <meta name="twitter:description" property="og:description" content="Your feedback is really important to us, so please feel free to drop us a line. If you are expecting a response, you will need to provide us your email* address, of course." />
    <meta property="og:site_name" content="www.coderepublics.com" />
    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:image" content="assets/img/CodeRepublics.jpg">
    <meta name="twitter:site" content="@coderepublics">
    <meta name="twitter:domain" content="www.coderepublics.com"/>
    <meta name="twitter:creator" content="@coderepublics"/>
    <?php include("../AdSense.php");?>
<?php include("../library.php");?>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="../assets/sidebar.php" />

<?php include("../assets/style.css");?>
</head>
<body>
    <?php include("../header.php");?>
    <?php include("../navbar.php");?>
       <div style="text-align: center; padding: 10px;">
      <!--  < ?php include("../Adds/rect_top_add.php");?></div>-->
            </div>
            <div class="container-fluid" style="border-bottom: 1px solid #ddd;
    border-top: 1px solid #ddd;">
  <div class="row">
            <div class="cold-lg-6 col-md-6 col-sm-6" style="background:white;">
                <h3 style="text-align:center;">We'd love to hear from you</h3>
						<h4 style="text-align:center;">Have Some Questions ?</h4><br><br>
                
                
                <div class="map-responsive">
<iframe src="https://maps.google.com/maps?q=dehradun&t=&z=13&ie=UTF8&iwloc=&output=embed" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
                </div>
                
    <div class="cold-lg-6 col-md-6 col-sm-6" style="border-left: 1px solid #ddd;background:white;
    height: 650px;">
                        <h3>Contact Us</h3>

    <div class="form-container">
        <form name="frmContact" id="" frmContact"" method="post"
            action="" enctype="multipart/form-data"
            onsubmit="return validateContactForm()">

            <div class="input-row">
                <label style="padding-top: 20px;">Name</label> <span
                    id="userName-info" class="info"></span><br /> <input
                    type="text" class="input-field" name="userName"
                    id="userName" placeholder="Your name.." />
            </div>
            <div class="input-row">
                <label>Email</label> <span id="userEmail-info"
                    class="info"></span><br /> <input type="text"
                    class="input-field" name="userEmail" id="userEmail" placeholder="Email" />
            </div>
            <div class="input-row">
                <label>Subject</label> <span id="subject-info"
                    class="info"></span><br /> <input type="text"
                    class="input-field" name="subject" id="subject" placeholder="Subject"/>
            </div>
            <div class="input-row">
                <label>Message</label> <span id="userMessage-info"
                    class="info"></span><br />
                <textarea name="content" id="content"
                    class="input-field" cols="60" rows="6"  placeholder="Your Message..."></textarea>
            </div>
            <div>
                <input type="submit" name="send" class="btn-submit"
                    value="Send" />

                <div id="statusMessage"> 
                        <?php
                        if (! empty($message)) {
                            ?>
                       <div class="alert alert-success" class='<?php echo $type; ?>Message'><?php echo $message; ?>
</div>                  <?php
                        }
                        ?>
                    </div>
            </div>
        </form>
    </div>
</div>
   </div>
</div>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"
        type="text/javascript"></script>
    <script type="text/javascript">
        function validateContactForm() {
            var valid = true;

            $(".info").html("");
            $(".input-field").css('border', '#e0dfdf 1px solid');
            var userName = $("#userName").val();
            var userEmail = $("#userEmail").val();
            var subject = $("#subject").val();
            var content = $("#content").val();
            
            if (userName == "") {
                $("#userName-info").html("Required.");
                $("#userName").css('border', '#e66262 1px solid');
                valid = false;
            }
            if (userEmail == "") {
                $("#userEmail-info").html("Required.");
                $("#userEmail").css('border', '#e66262 1px solid');
                valid = false;
            }
            if (!userEmail.match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/))
            {
                $("#userEmail-info").html("Invalid Email Address.");
                $("#userEmail").css('border', '#e66262 1px solid');
                valid = false;
            }

            if (subject == "") {
                $("#subject-info").html("Required.");
                $("#subject").css('border', '#e66262 1px solid');
                valid = false;
            }
            if (content == "") {
                $("#userMessage-info").html("Required.");
                $("#content").css('border', '#e66262 1px solid');
                valid = false;
            }
            return valid;
        }
</script>
<!--<div class="ad-height">
    < ?php include("../Adds/rect_top_add.php");?></div>--><br><br><br><br>
<?php include("../footer.php");?>
</body>
 <?php include("../script.php");?>-->

</html>

<script>
window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 4000);
</script>
<style>
.gsc-search-button .gsc-search-button-v2{
    padding: 10.5px !important;
}
}

</style>